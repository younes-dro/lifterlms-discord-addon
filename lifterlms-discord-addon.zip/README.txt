=== Connect LifterLMS to Discord ===
Contributors: expresstechsoftware, webbdeveloper, sunnysoni 
Tags: Discord, Talk, Video Chat, Hang Out, Friends, Memberships, discord role management, lms, LifterLMS, learning community management.
Donate link: https://paypal.me/supportets
Author URI: https://www.expresstechsoftwares.com
Author: ExpressTech Software Solutions Pvt. Ltd.
Requires at least: 4.7
Tested up to: 6.5
Requires PHP: 7.0
Stable tag: 1.0.10
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create a community of your students by connecting your LifterLMS Website to your Discord server.

== Description ==
This add-on enables connecting your LifterLMS-enabled website to your discord server. With this plugin, you can create a discord community of your students and assign them discord roles in the server according to the course they are learning.
private access to course content plus discord's ability to add fun and creativity in community engagement will help create a thriving community, discord is safe and designed to help fight spam and promote healthy community discussions.
This plugin promotes Engagement, Upsell and cross-sell opportunities, Advocacy, and referrals that ultimately help increase revenues.

Very simple setup and intutive User interface to Manage Student Role inside Discord.
- Please always contact support if you are facing issues in setup or see any bug.
- If you did like the plugin, kindly support us in doing free excellent work our PayPal email is: business@expresstechsoftwares.com

Connect LifterLMS to Discord Plugin Features:
1) Allow any student to connect their discord account with their LifterLMS website account.

2) Shortcode [lifterlms_discord] to display connect/disconnect button.

3) Mapping of courses and discord roles.

4) Send custom welcome message when student joins the server.

5) Send custom message when student completes a course.

6) Send custom message when student completes a lesson.

7) Send custom message when student completes a topic.

8) Send custom message when student completes a quiz.

9) Send custom message when  Achievement is earned.

10) Send custom message when  Certificate is earned.

== Installation ==

= Download, Install and Activate! =
1. Go to Plugins > Add New to find and install connect LifterLMS discord Addon.
2. Or, download the latest version of the plugin, then go to Plugins > Add New and click the "Upload Plugin" button to upload your .zip file.
3. Activate the plugin.

== Checkout Our Other Plugins ==
1. [Connect MemberPress and Discord](https://wordpress.org/plugins/expresstechsoftwares-memberpress-discord-add-on/)
2. [Connect PaidmembershipPro and Discord](https://wordpress.org/plugins/pmpro-discord-add-on/)
3. [Connect ProfilePress and Discord](https://wordpress.org/plugins/connect-profilepress-and-discord/)
4. [Connect Learnpress and Discord](https://wordpress.org/plugins/connect-learnpress-discord-add-on/)
5. [Connect MemberPress and Discord](https://wordpress.org/plugins/expresstechsoftwares-memberpress-discord-add-on/)
6. [Webhook For WCFM Vendors](https://wordpress.org/plugins/webhook-for-wcfm-vendors/)
7. [Inspect HTTP Requests](https://wordpress.org/plugins/inspect-http-requests/)
8. [Product Questions & Answers for WooCommerce](https://wordpress.org/plugins/product-questions-answers-for-woocommerce/)
9. [Connect Ultimate Member and Discord](https://wordpress.org/plugins/ultimate-member-discord-add-on/)
10. [Connect BadgeOS and Discord](https://wordpress.org/plugins/connect-badgeos-to-discord/)
11. [Connect Eduma Theme and  Discord](https://wordpress.org/plugins/connect-eduma-theme-to-discord/)
12. [Connect Restrict Content Pro and Discord Addon](https://wordpress.org/plugins/connect-restrictcontentpro-to-discord-addon/)
13. [Connect GamiPress and Discord](https://wordpress.org/plugins/connect-gamipress-and-discord/)

== Frequently Asked Questions ==
= I'm getting an error in error Log 'Missing Access'
Please make sure your bot role has the highest priority among all other roles in your discord server roles settings.
= I'm getting an error in error Log 'Missing Access'
Please make sure your bot role has the high priority among all other roles your bot has to manager in your discord server roles settings.
= Role Settings is not appearing.
1. Clear browser cache, to uninstall and install again.
2. Try the disabling cache
3. Try Disabling other plugins, there may be any conflict with another plugin.
= Members are not being added spontaneously.
1. Due to the nature of Discord API, we have to use schedules to precisely control API calls, This is the reason actions are delayed. 
= Student roles are not being assigned spontaneously.
1. Due to the nature of Discord API, we have to use schedules to precisely control API calls, This is the reason actions are delayed. 
= Some Sutudents are not getting their role and there is no error in the log.
1. Sometimes discord API behaves weirdly, It is suggested to TRY again OR use another discord account.


== Screenshots ==
1. Install and activate the plugin and view the "Discord Settings" menu inside LifterLMS LMS.
2. Map Discord roles and LifterLMS Course.
3. Advanced settings.
4. Spot the "Connect to Discord" on Dashboard profile page.
5. Connect Button Appearance.
6. Reporting single student overview widget